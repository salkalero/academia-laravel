<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Primer Blade</title>
    <style>
        body { font-family: sans-serif; background: #f3f4f6; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .card { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #ff2d20; }
    </style>
</head>
<body>
    <div class="card">
<!-- Las dobles llaves son el equivalente a < ?php echo $nombreUsuario; ?> que se
usaba en PHP puro, pero es más límpio y seguro, ya que está protegido 
automáticamente por ataques XSS -->
        <h1>¡Hola <?php echo e($nombreUsuario); ?>!</h1>
        <p>Esta pantalla ya no es texto plano, ¡es una vista Blade real en Laravel 13!</p>
    </div>
</body>
</html><?php /**PATH /var/www/html/resources/views/saludo2.blade.php ENDPATH**/ ?>